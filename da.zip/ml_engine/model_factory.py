from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout


def create_lstm_model(input_shape):
    model = Sequential()

    # Промяна 1: Увеличаваме невроните на 64
    model.add(LSTM(units=64, return_sequences=True, input_shape=input_shape))
    # Промяна 2: Намаляваме Dropout на 0.1 (по-малко забравяне)
    model.add(Dropout(0.1))

    model.add(LSTM(units=64, return_sequences=False))
    model.add(Dropout(0.1))

    model.add(Dense(units=1))

    # Промяна 3: Използваме 'huber' loss, който е по-устойчив на аномалии от MSE
    model.compile(optimizer='adam', loss='huber')
    return model