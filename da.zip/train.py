import os
import numpy as np
import matplotlib.pyplot as plt
from ml_engine.config import SYMBOL, START_DATE, LOOK_BACK, MODELS_DIR, PLOTS_DIR
from ml_engine.data_loader import CryptoDataLoader
from ml_engine.model_factory import create_lstm_model


def main():
    print("🚀 Стартиране на системата за обучение...")

    # 1. Зареждане на данни
    loader = CryptoDataLoader(SYMBOL, START_DATE)
    df = loader.fetch_data()

    # 2. Подготовка (Pre-processing)
    X, y, scaler = loader.prepare_lstm_data(df, LOOK_BACK)

    # Разделяне на Train/Test (80% обучение, 20% валидация)
    split_idx = int(len(X) * 0.8)
    X_train, y_train = X[:split_idx], y[:split_idx]
    X_test, y_test = X[split_idx:], y[split_idx:]

    print(f"📊 Размер на данните за обучение: {X_train.shape}")
    print(f"📊 Размер на данните за тест: {X_test.shape}")

    # 3. Създаване на модела
    model = create_lstm_model((X_train.shape[1], 1))

    # 4. Обучение
    print("🧠 Започва обучение на невронната мрежа (това ще отнеме време)...")
    history = model.fit(
        X_train, y_train,
        epochs=50,  # <-- УВЕЛИЧАВАМЕ НА 50
        batch_size=16,  # <-- НАМАЛЯВАМЕ НА 16 (помага за по-финно обучение)
        validation_data=(X_test, y_test),
        verbose=1
    )

    # 5. Запазване на модела
    model_path = os.path.join(MODELS_DIR, 'bitcoin_lstm.keras')
    model.save(model_path)
    print(f"✅ Моделът е запазен успешно в: {model_path}")

    # 6. Визуализация на процеса на обучение (Loss)
    plt.figure(figsize=(10, 6))
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.title('Графика на грешката (Loss) по време на обучение')
    plt.xlabel('Епоха')
    plt.ylabel('Loss (MSE)')
    plt.legend()

    plot_path = os.path.join(PLOTS_DIR, 'training_loss.png')
    plt.savefig(plot_path)
    print(f"📈 Графиката на обучението е запазена в: {plot_path}")

    # Показване на графиката
    plt.show()


if __name__ == "__main__":
    main()